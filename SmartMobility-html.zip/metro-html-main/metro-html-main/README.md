# Smart Mobility Challenge

## Authors

#### Alexis Rondo

#### Lucas Chicote

#### Lucas Gomes

## Guide to run the project
